from django.db.models import Max
from django.db.models import Q, Sum
import datetime
from rest_framework import viewsets
from .serializers import IncomingFundSerializer, OutgoingFundSerializer, ExpenseTypeSerializer, JournalVoucherSerializer
from .models import IncomingFund, OutgoingFund, ExpenseType, JournalVoucher
from rest_framework.views import APIView
from rest_framework.response import Response
from datetime import date
from booking.models import Booking
from customer.models import Customers


class IncomingFundViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows IncomingFund to be viewed or edited.
    """
    serializer_class = IncomingFundSerializer

    def get_queryset(self):
        queryset = IncomingFund.objects.all().select_related(
            'booking', 'booking__customer', 'booking__plot')

        project_id = self.request.query_params.get('project')
        if project_id:
            queryset = queryset.filter(project_id=project_id)
        return queryset


class OutgoingFundViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows OutgoingFund to be viewed or edited.
    """
    serializer_class = OutgoingFundSerializer

    def get_queryset(self):
        queryset = OutgoingFund.objects.all()
        project_id = self.request.query_params.get('project')
        if project_id:
            queryset = queryset.filter(project_id=project_id)
        return queryset


class JournalVoucherViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows JournalVoucher to be viewed or edited.
    """
    serializer_class = JournalVoucherSerializer

    def get_queryset(self):
        queryset = JournalVoucher.objects.all()
        project_id = self.request.query_params.get('project')
        if project_id:
            queryset = queryset.filter(project_id=project_id)
        return queryset


class ExpenseTypeViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows ExpenseType to be viewed or edited.
    """
    serializer_class = ExpenseTypeSerializer

    def get_queryset(self):
        queryset = ExpenseType.objects.all()
        project_id = self.request.query_params.get('project')
        if project_id:
            queryset = queryset.filter(project_id=project_id)
        return queryset


class DuePaymentsView(APIView):
    def get(self, request):
        today = date.today()

        current_month = datetime.date.today().replace(day=1)
        active_bookings = Booking.objects.filter(status="active")

        defaulter_bookings = []

        for booking in active_bookings:
            latest_payment = IncomingFund.objects.filter(
                booking=booking).aggregate(latest_date=Max('date'))

            if latest_payment['latest_date']:
                latest_payment_obj = IncomingFund.objects.filter(
                    booking=booking, date=latest_payment['latest_date']).first()

                if latest_payment_obj.installement_month != current_month:
                    # Calculate the difference in months
                    month_diff = (current_month.year - latest_payment_obj.installement_month.year) * 12 + \
                        (current_month.month -
                         latest_payment_obj.installement_month.month)

                    # Append the booking object along with the month difference
                    defaulter_bookings.append({
                        'booking': booking,
                        'month_difference': month_diff
                    })

        due_payments = []
        for defaulter_booking in defaulter_bookings:
            booking = defaulter_booking['booking']
            month_diff = defaulter_booking['month_difference']
            customer = Customers.objects.get(pk=booking.customer_id)
            due_payments.append({
                'booking_id': booking.booking_id,
                'customer_name': customer.name,
                'customer_contact': customer.contact,
                'due_date': booking.due_date,
                'total_remaining_amount': booking.remaining,
                'month_difference': month_diff
            })

        return Response({'due_payments': due_payments})
